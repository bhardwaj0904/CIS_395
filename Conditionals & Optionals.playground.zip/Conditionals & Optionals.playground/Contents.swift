import UIKit

//Conditionals
//if statements

let isRestaurantOpen = true

if isRestaurantOpen {
    print("Restaurant is open")
}

let isRestaurantFound = false

if isRestaurantFound == false{
    
}

// optionals

var spouseName: String?

spouseName = nil

print(spouseName ?? "no value")

//spouseName!.uppercased()

// optional binding
if let spouseTemVar = spouseName {
      let upp = spouseName!.uppercased()
      print(upp)}
    else {
       print("No uppercased")
}


// Range
let myRange =  10...20

// for-in loop
for myValue in myRange{
    print(myValue)
}

//Array
var shoppingList = ["milk","eggs", "bread", "butter"]

shoppingList.sort()
shoppingList.last
shoppingList.append("cooking oil")

shoppingList = shoppingList + ["Rise"]

shoppingList.insert("fish", at: 1)

shoppingList[3]

shoppingList[2] = "Soy Milk"
shoppingList

shoppingList.remove(at: 2)
shoppingList

for items in shoppingList{
    print(items)
}


var contactList = ["Shah" : "+60123456789", "Aamir" : "+0223456789"]

contactList["Aamir"] = nil

//contactList.removeValue(forKey: "Shah")
contactList
