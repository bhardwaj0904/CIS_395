//
//  ViewController.swift
//  FirstProjectApp
//
//  Created by Bhardwaj, Bhavana on 7/1/25.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func clickButton(_ sender: Any) {
        
        imageView.image = UIImage(named: "Yellow")
        
    }
}

