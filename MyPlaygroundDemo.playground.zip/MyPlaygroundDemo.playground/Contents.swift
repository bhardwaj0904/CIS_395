import UIKit


func serviceCharge(){
    let mealCost = 50
    let serviceCharge = mealCost/10
    print("Service charge is \(serviceCharge)")
    
}

serviceCharge()

//WITH PARAMERTES AND RETURN TYPE
func serviceCharge(mealCost: Int) -> Int{
    return mealCost/10
}

let serviceChargeCal = serviceCharge(mealCost: 100)
print(serviceChargeCal)


//Add parameters


func serviceCharge1(forMealPrice mealCost:Int) -> Int{
      mealCost/10
    
}

let serviceChargeAmount = serviceCharge1(forMealPrice: 50)

print("Service charge is \(serviceChargeAmount)")

//laonAmoount = 50000 - 5000 = 45000
//totalInterestAmount() = 3.5* 7 = 24.5
//numberOfMounts() = 7*12 = 84

//(45000 +(45000*24.5/100))/84 = 666.96

// guard
func greet(name: String?){
    guard let unwrappedName = name else{
        print("No name provided")
        return   }
    print("Hello, \(unwrappedName)")
}

greet(name: "bhavana")


func greet1(name: String?){
    if let unwrappedName = name{
        print("hello, \(unwrappedName)")
    } else{
        print("No name was provided")
    }
}

greet1(name: nil)

//multiple input example
func registerUser(email: String?, password: String?){
    guard let email = email, !email.isEmpty else{
        print("email is missing")
        return
    }
    guard let password = password,
          password.count >= 6 else{
            
        print("password is too short")
        return
        
    }
    print("User registered with email: \(email)")
}

registerUser(email: "example@gmail.com", password: "sgig")

// class
//class Animal{
 // var name: String = ""
 // var sound: String = ""
  //var legs: Int = 0
  //var breathesOxygen: Bool = true
 // func makeSound(){
  //    print(sound)
 //   }
//}

//Animal instance - cat

//let cat = Animal()//create instance
//print(cat.name)
//print(cat.sound)
//print(cat.legs)
//print(cat.breathesOxygen)
//cat.makeSound()

// Assign some values

//cat.name = "Whiskers"
//print(cat.name)

//cat.sound = "Meow"
//print(cat.sound)

//cat.legs = 4
//print(cat.legs)

//cat.breathesOxygen = true
//print(cat.breathesOxygen)


// initialize instance properties
//comment Animal class above
//ADD description function

class Animal {
var name: String
var sound: String
var numberOfLegs: Int
var breathesOxygen: Bool
init(name: String, sound: String, numberOfLegs:
     Int, breathesOxygen: Bool) {
  self.name = name
  self.sound = sound
  self.numberOfLegs = numberOfLegs
  self.breathesOxygen = breathesOxygen
}
func makeSound() {
print(sound)
}
    func description() -> String {
        return """
            name: \(name)
            sound: \(sound)
            numberOfLegs: \(numberOfLegs)
            breathesOxygen: \(breathesOxygen)
            """
    }
}

//let cat = Animal(name: "Whiskers", sound: "Meow", numberOfLegs: 4, breathesOxygen: true)

//print(cat.name)
//print(cat.sound)
//print(cat.numberOfLegs)
//print(cat.breathesOxygen)
//cat.makeSound()

// subclass mammal

class Mammal: Animal {
    let hasFurOrHair: Bool = true
    //override func description() -> String {
      //  super.description()+"\nhasFurOrHair: \(hasFurOrHair)"
  //  }
}

let dog = Mammal(name: "Bella", sound: "Arf", numberOfLegs: 4, breathesOxygen: true)


//print(dog.name)
//print(dog.sound)
//print(dog.numberOfLegs)
//print(dog.breathesOxygen)

print(dog.description())
dog.makeSound()
print(dog.hasFurOrHair)


//structure

struct Reptile {
    var name: String
    var sound: String
    var numberOfLegs: Int
    var breathesOxygen: Bool
    func makeSound() {
    print(sound)
    }
    func description() -> String {
        return """
            name: \(name)
            sound: \(sound)
            numberOfLegs: \(numberOfLegs)
            breathesOxygen: \(breathesOxygen)
            """
    }
}

let snake = Reptile(name: "Sssss", sound: "ssss", numberOfLegs: 0, breathesOxygen: false)
print(snake.description())
snake.makeSound()

//structure value type

struct SmapleValueType{
    var sampleProperty = 10
}

var a = SmapleValueType()
var b = a

//print(b.sampleProperty)

b.sampleProperty = 20

//print(a.sampleProperty)
//print(b.sampleProperty)

// REFERENCE TYPE

class SampleReferenceType{
    var sampleProperty = 10
}

var c = SampleReferenceType()
var d = c

print(d.sampleProperty)

d.sampleProperty = 20

//print(c.sampleProperty)
//print(d.sampleProperty)

//Enumeration

enum TrafficLightColor {
    case red
    case yellow
    case green
    
    func description() -> String{
        switch self {
        case .red:
            return "Red"
        case .yellow:
            return "Yellow"
        case .green:
            return "Green"
        }
    }
}
var trafficLightColor = TrafficLightColor.green
//print(trafficLightColor)
print(trafficLightColor.description())


enum Direction{
    case north, south, east, west
}

let dir = Direction.west

switch dir {
case .east:
    print("East")
default:
    print("Not East")
}

