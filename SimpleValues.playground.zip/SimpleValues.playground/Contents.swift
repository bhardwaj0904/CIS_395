import UIKit

var greeting = "Hello, playground"

5 + 3

// simpleValues
42
-23

3.14159
0.1
-273.15

"hello world"

true
false

// Variables & Constants

//userName = "kate"

var userName = "James"

// operations on variables
userName.append("o")
userName.lowercased()
userName.uppercased()

print(userName)
var userSurname = "Bond"

userName = "Lars"
print(userName)

//constant


let isRaining = true

// type annotation

var restaurantRating: Double = 4.7

// type safty
//restaurantRating = "Good"

// Type Conversion
let intVal = 5
let doubleVal: Double = Double(intVal)

// compound operators
var d = 1
d += 2
d -= 1

//logical opertors
(1 == 1) && (2 == 2)
(1 == 1) || (2 == 2)
(1 == 1) && (2 != 2)
!(1 == 1)
