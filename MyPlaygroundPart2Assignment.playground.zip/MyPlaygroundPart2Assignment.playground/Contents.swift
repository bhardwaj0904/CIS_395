import UIKit

//task 1

let age = 45

// question 1: if-else statement
if age < 13 {
    print("Child")
} else if age >= 13 && age < 20 {
    print("Teenager")
} else if age >= 20 && age < 60 {
    print("Adult")
} else {
    print("Senior")
}

// question 2: switch statement for even/odd
switch age % 2 {
case 0:
    print("Even age")
default:
    print("Odd age")
}

// task 2

var favoriteNumber: Int? = 25   // Try changing this to 25

// Part a: optional binding
if let number = favoriteNumber {
    print("Your favorite number is \(number)")
} else {
    print("No favorite number set")
}

// Part b: nil-coalescing operator
let safeNumber = favoriteNumber ?? 7
print("Favorite number with default is \(safeNumber)")

//task 3

let scores = [72, 88, 95, 63, 80, 99]

// Part a: find highest score
var highest = scores[0]
for score in scores {
    if score > highest {
        highest = score
    }
}
print("Highest score is \(highest)")

// Part b: print scores > 85
for score in scores where score > 85 {
    print("Score above 85: \(score)")
}

// Part c: count scores < 70
var countBelow70 = 0
var index = 0
while index < scores.count {
    if scores[index] < 70 {
        countBelow70 += 1
    }
    index += 1
}
print("Number of scores below 70: \(countBelow70)")

//task 4
var cities = ["New York": 8_300_000, "Boston": 700_000, "Chicago": 2_700_000]

// Part a: print cities
for (city, population) in cities {
    print("\(city): \(population)")
}

// Part b: add new city
cities["San Francisco"] = 870_000

// Part c: update Boston
cities["Boston"] = 750_000

// Part d: remove Chicago
cities.removeValue(forKey: "Chicago")

print("Updated cities: \(cities)")

//task 5

let mixedArray: [Any] = [42, "Swift", 3.14, true]

for item in mixedArray {
    if let intValue = item as? Int {
        print("Integer value: \(intValue)")
    } else if let stringValue = item as? String {
        print("String value: \(stringValue)")
    } else if let doubleValue = item as? Double {
        print("Double value: \(doubleValue)")
    } else if let boolValue = item as? Bool {
        print("Boolean value: \(boolValue)")
    }
}

//You’re given an array that holds values of different types (Int, String, Double, Bool).

//Since Swift arrays normally hold only one type, we use [Any] so it can store anything.

//The task: loop through the array and figure out what type each element is, then print it.
//Loop through each element of mixedArray.

//First: 42

//Second: "Swift"

//Third: 3.14

//Fourth: true

// item as? (optional downcasting) to check the type:

// item as? Int → works if the item is an integer.

//item as? String → works if it’s a string.

//item as? Double → works if it’s a decimal number.

// item as? Bool → works if it’s true/false.

//If the cast succeeds, the if let binding stores the value in a new variable (intValue, stringValue, etc.), and we print it.
//In short:

//Any lets you mix different types in one array.

//as? is used to safely check and convert to the correct type.

//This is useful when handling dynamic or mixed data (e.g., JSON parsing, user inputs).
